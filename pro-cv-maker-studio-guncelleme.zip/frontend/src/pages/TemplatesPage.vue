<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import CvTemplateThumbnail from '@/components/cv/CvTemplateThumbnail.vue'
import DocumentFormModal from '@/components/dashboard/DocumentFormModal.vue'
import { cvApi, portfolioApi } from '@/services/documents'
import { useUiStore } from '@/stores/ui'

const router = useRouter()
const ui = useUiStore()
const cvTemplates = ref([])
const portfolioTemplates = ref([])
const loading = ref(true)
const error = ref('')
const createOpen = ref(false)
const selectedTemplate = ref('')

function openCreate(templateId = '') {
  selectedTemplate.value = templateId
  createOpen.value = true
}
const ATS_TEMPLATES = ['professional', 'minimal', 'corporate', 'academic', 'compact']

onMounted(async () => {
  try {
    ;[cvTemplates.value, portfolioTemplates.value] = await Promise.all([cvApi.templates(), portfolioApi.templates()])
  } catch (err) {
    error.value = err.message
  } finally {
    loading.value = false
  }
})

function onCreated(doc) {
  ui.toast(`“${doc.title}” oluşturuldu.`, 'success')
  router.push(`/cvs/${doc.id}`)
}
</script>

<template>
  <div>
    <section class="page-header">
      <div class="gallery-intro"><p class="eyebrow mb-1">Tasarım kütüphanesi</p><h2 class="page-title">Şablon Galerisi</h2><p class="text-secondary mb-0">Her düzen aynı içerikle çalışır. Dilediğiniz zaman şablon değiştirin; bilgileriniz ve tasarım tercihleriniz korunsun.</p></div>
      <button type="button" class="btn btn-primary" @click="openCreate()"><i class="bi bi-plus-lg me-1"></i>Yeni CV oluştur</button>
    </section>
    <div v-if="error" class="alert alert-danger d-flex justify-content-between align-items-center" role="alert"><span>Şablonlar yüklenemedi: {{ error }}</span><button class="btn btn-sm btn-outline-danger" @click="$router.go(0)">Tekrar dene</button></div>
    <div v-if="loading" class="py-5 text-center text-secondary"><span class="spinner-border spinner-border-sm me-2"></span>Şablonlar hazırlanıyor…</div>
    <template v-else>
      <div class="gallery-section-title"><i class="bi bi-file-earmark-person text-primary"></i><h3>CV şablonları</h3><span>{{ cvTemplates.length }} kullanılabilir tasarım</span></div>
      <div class="row g-4 mb-5">
        <div v-for="t in cvTemplates" :key="t.id" class="col-sm-6 col-xl-4">
          <article class="card h-100 template-card">
            <div class="template-card-top"><span class="template-badge"><i class="bi bi-check-circle-fill text-success"></i>Kullanılabilir</span><span v-if="ATS_TEMPLATES.includes(t.id)" class="template-badge template-badge--ats"><i class="bi bi-shield-check"></i>ATS dostu</span></div>
            <CvTemplateThumbnail :template="t.id" />
            <div class="card-body"><div class="d-flex align-items-center justify-content-between gap-2"><h4 class="h6 mb-1">{{ t.name }}</h4><button type="button" class="btn btn-sm btn-outline-primary" @click="openCreate(t.id)">Bu şablonla başla</button></div><p class="small text-secondary mb-0">{{ t.description }}</p></div>
          </article>
        </div>
      </div>

      <div class="gallery-section-title"><i class="bi bi-window-sidebar text-primary"></i><h3>Portfolyo şablonları</h3><span>{{ portfolioTemplates.length }} tema</span></div>
      <div class="row g-3">
        <div v-for="(t, index) in portfolioTemplates" :key="t.id" class="col-md-6 col-xl-4"><div class="card h-100"><div class="card-body d-flex gap-3"><span class="stat-icon flex-shrink-0"><i :class="['bi', index % 2 ? 'bi-window-desktop' : 'bi-columns-gap']"></i></span><div><h4 class="h6 mb-1">{{ t.name }}</h4><p class="small text-secondary mb-0">{{ t.description }}</p></div></div></div></div>
      </div>
      <div class="alert alert-info border-0 mt-4 mb-0 small"><i class="bi bi-info-circle me-2"></i>CV şablonlarının tamamı canlı editörde ve PDF çıktısında kullanılabilir. Portfolyo editörü geliştirilmeye devam ediyor.</div>
    </template>
    <DocumentFormModal :open="createOpen" kind="cv" :templates="cvTemplates" :initial-template="selectedTemplate" @saved="onCreated" @close="createOpen = false" />
  </div>
</template>
